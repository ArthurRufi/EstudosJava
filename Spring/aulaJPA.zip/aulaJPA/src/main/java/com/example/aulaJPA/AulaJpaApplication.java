package com.example.aulaJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulaJpaApplication.class, args);
	}

}
